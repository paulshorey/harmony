module.exports = require('@spiral/config/eslint-preset')(__dirname);
