module.exports = require('@spiral/config/jest-config');
