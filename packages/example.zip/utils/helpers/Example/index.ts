export const add = (n1: number, n2: number) => {
  return n1 + n2;
};
