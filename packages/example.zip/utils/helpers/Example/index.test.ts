import { add } from '.';

describe('Can Add numbers', () => {
  it('Works', () => {
    expect(add(2, 2)).toEqual(4);
  });
});
