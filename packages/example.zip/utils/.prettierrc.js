module.exports = require('@spiral/config/prettier-preset');
